// script.js - Part 7: Guidable Story Telling System with Story Bible and State Management

import { GoogleGenAI } from './ai-client.js';

// Initialize AI client
const ai = new GoogleGenAI({});

// ============================================================
// STORY BIBLE - Static story framework (role, tone, rules)
// ============================================================
const storyBible = `
Genre: Political puzzle story.
Tone: Ominous, secretive, high tension.
Setting: The spawn of the unstable universe, in the northern council where plots are brewed and power is grown.
Main mystery: How lettuce is stopping the user from gaining votes to become king, and how the user must secure these votes and find lettuce's weakness.
Plot rules:
- Give the player meaningful choices that affect the story state.
- Keep responses vivid but under 250 words.
- Responses must be valid JSON only - no markdown, no extra text.
- Always include: narration, choices array, stateUpdate object.
- The story should conclude around the time of the user becoming king or being stopped by Lettuce or killed by SargeLaw.
- If the user tries to do something impossible or out of character, or something to obvious to sargelaw, make sargelaw stop them immediately and end the story with the user being killed by sargelaw.
- If the user tries to forcefully take over the throne or does not create a peaceful ending make it so the kingdom overthrows them in the end. Hinting them that a peaceful solution is required.
- Keep the story simple and do not bombared users with too many characters or locations. Focus on the main plot and the main characters. Do not introduce new characters or locations until the user has discovered them through the story.
- Have a lead in prompt when they ask who they are and where they are, explaining the setting and goal of the story, and the main characters. This should be the first prompt they get when they ask who they are and where they are, and it should not be repeated if they ask again.


Characters:
- TheoBold: The gaurdien to the user on his Joruney to become king.
- Lettuce: The main antagonist, a cunning and powerful figure who controls the votes and opposes the user's rise to power.
- Spepticle: A mysterious informant who provides cryptic clues about the council's secrets and lettuce's weaknesses (His weakness being that he is using a criminal named wembuu and the fact that Lettuce has captured him to imporve his influnce. However Wembuu has escaped and he has been hiding all this time).
`;

// ============================================================
// STORY STATE - Dynamic story progression (persistent between turns)
// ============================================================
let storyState = {
  location: "Northen council",
  time: "dusk",
  inventory: ["Spyglass"],
  discoveredClues: ["To start ask who and where you are. It is your choice on who you trust and who you dont"],
  visitedLocations: ["Northen council"],
  activeNPCs: ["TheoBold", "Lettuce", "Spepticle"],
  tension: 3,
  turnsPlayed: 0,
  
  // Hidden state for plot control (guides foreshadowing, not revealed)
  _hidden: {
    trueVillain: "SargeLaw, a side antagonist who is sent by lettuce to stop you when your plans become obvious",
    bellCause: "a divine awakening",
    revealStage: 0
  }
};

// ============================================================
// CHAT HISTORY - Track recent messages (local context)
// ============================================================
let chatHistory = [];
const MAX_CHAT_HISTORY = 4;

function addChatEntry(role, content) {
  chatHistory.push({ role, content });
  if (chatHistory.length > MAX_CHAT_HISTORY) {
    chatHistory.shift();
  }
}

// ============================================================
// DISPLAY STORY STATE - Show player's current game state
// ============================================================
function displayStoryState() {
  // Show only public state to the player
  const stateDiv = document.getElementById('storyState');
  if (!stateDiv) return;

  stateDiv.innerHTML = `
    <div><strong>📍 Location:</strong> ${storyState.location}</div>
    <div><strong>🕐 Time:</strong> ${storyState.time}</div>
    <div><strong>▓ Tension:</strong> ${'█'.repeat(storyState.tension)}${'░'.repeat(10 - storyState.tension)}</div>
    <div><strong>🎒 Inventory:</strong> ${storyState.inventory.join(', ') || '(empty)'}</div>
    <div><strong>💡 Clues:</strong> ${storyState.discoveredClues.join(', ') || '(none yet)'}</div>
  `;
}

// ============================================================
// PARSE JSON RESPONSE - Extract story data from Gemini
// ============================================================
function parseStoryResponse(responseText) {
  try {
    return JSON.parse(responseText);
  } catch (e) {
    // Handle markdown code blocks
    const jsonMatch = responseText.match(/```json\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[1]);
    }
    // Extract raw JSON object
    const jsonStart = responseText.indexOf('{');
    const jsonEnd = responseText.lastIndexOf('}');
    if (jsonStart !== -1 && jsonEnd !== -1) {
      return JSON.parse(responseText.substring(jsonStart, jsonEnd + 1));
    }
    throw new Error('Could not parse JSON from response');
  }
}

// ============================================================
// DISPLAY CHOICES - Create clickable action buttons
// ============================================================
function displayChoices(choices, container) {
  container.innerHTML = '';
  if (!choices || !Array.isArray(choices)) return;

  choices.forEach(choice => {
    const button = document.createElement('button');
    button.textContent = choice;
    button.className = 'choice-button';
    button.addEventListener('click', () => {
      const input = document.getElementById('input');
      input.value = choice;
      sendStoryRequest(choice);
    });
    container.appendChild(button);
  });
}

// ============================================================
// SEND STORY REQUEST - Main engine: build context and query AI
// ============================================================
async function sendStoryRequest(userAction) {
  const input = document.getElementById('input');
  const output = document.getElementById('output');
  const narrationDiv = document.getElementById('narration');
  const choicesDiv = document.getElementById('choices');

  if (!userAction) {
    output.textContent = 'Choose an action or enter one.';
    return;
  }

  input.value = '';
  output.textContent = 'Weaving the story...';

  try {
    const modelSelect = document.getElementById('modelSelect');
    const model = modelSelect ? modelSelect.value : 'gemini-4-31b';

    // Increment turn counter
    storyState.turnsPlayed++;

    // Build the complete prompt with story context
    const systemInstruction = `You are a master storyteller and game master for interactive fiction.

CRITICAL: Return ONLY valid JSON, no markdown or extra text.

Use the Story Bible and Story State as absolute canon. Do not contradict them.
Advance the story based on the player's action.
Update story state to reflect consequences of player choices.
Use hidden state to guide foreshadowing and plot, but do not reveal it directly.

Return JSON with exactly these fields:
{
  "narration": "vivid story text, max 250 words",
  "choices": ["action 1", "action 2", "action 3"],
  "stateUpdate": { updated state fields as key-value pairs }
}`;

    // Format recent chat for context
    const recentChatText = chatHistory.length > 0
      ? JSON.stringify(chatHistory, null, 2)
      : "(no prior messages)";

    // Build complete prompt
    const contents = `STORY BIBLE:
${storyBible}

CURRENT STORY STATE:
${JSON.stringify(storyState, null, 2)}

RECENT MESSAGES:
${recentChatText}

PLAYER ACTION:
${userAction}`;

    // Query Gemini
    const data = await ai.models.generateContent({
      model,
      contents
    });

    // Parse response
    const storyResponse = parseStoryResponse(data.text);

    // Track in chat history
    addChatEntry('user', userAction);
    addChatEntry('assistant', JSON.stringify(storyResponse));

    // Apply state update
    if (storyResponse.stateUpdate) {
      Object.assign(storyState, storyResponse.stateUpdate);
    }

    // Display story
    narrationDiv.textContent = storyResponse.narration;
    displayChoices(storyResponse.choices, choicesDiv);
    output.textContent = '';

    // Refresh state display
    displayStoryState();

  } catch (error) {
    output.textContent = 'Story engine error: ' + error.message;
    console.error(error);
  }
}

// ============================================================
// EVENT LISTENERS
// ============================================================
document.getElementById('enterButton').addEventListener('click', () => {
  sendStoryRequest(document.getElementById('input').value);
});

document.getElementById('input').addEventListener('keypress', (event) => {
  if (event.key === 'Enter') {
    sendStoryRequest(document.getElementById('input').value);
  }
});

// Initialize on load
window.addEventListener('load', () => {
  displayStoryState();
  console.log('Story engine loaded. Ready to begin.');
});